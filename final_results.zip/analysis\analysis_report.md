# Analysis report: Wavelet vs Shearlet denoising

_Generated from `data\results\benchmark_results.csv`. Numbers only; read the limitations at the end._

## 1. Data scope

- Experiments: 180 (images: camera, coins, moon; seeds: 42, 43, 44, 45, 46)
- Noise types and levels: gaussian: 10, 20, 30; salt_pepper: 0.02, 0.05, 0.1; speckle: 0.1, 0.2, 0.3; mixed: 10, 20, 30
- Parameter conditions: tuned, default (tuned = best of an equal-size grid per method, chosen by PSNR against the clean image)

**How to read the tables.** Differences are shearlet minus wavelet, so a positive PSNR or SSIM difference means shearlet scored higher. `[95% CI]` is a t interval over paired runs; if it excludes 0 the difference is called clear. n is the number of paired runs (images × seeds). Runs from the same image are not independent, so intervals are somewhat optimistic.

## 2. Which method reduces Gaussian noise more effectively?

**tuned parameters**

| noise | level | n | PSNR diff dB [95% CI] | SSIM diff [95% CI] | PSNR runs shearlet higher | verdict |
|---|---|---|---|---|---|---|
| gaussian | 10 | 15 | +1.29 [+1.11, +1.47] | +0.045 [+0.033, +0.056] | 15/15 | shearlet higher on PSNR and SSIM |
| gaussian | 20 | 15 | +1.45 [+1.08, +1.82] | +0.072 [+0.045, +0.099] | 15/15 | shearlet higher on PSNR and SSIM |
| gaussian | 30 | 15 | +1.45 [+1.01, +1.89] | +0.075 [+0.050, +0.100] | 15/15 | shearlet higher on PSNR and SSIM |

**default parameters**

| noise | level | n | PSNR diff dB [95% CI] | SSIM diff [95% CI] | PSNR runs shearlet higher | verdict |
|---|---|---|---|---|---|---|
| gaussian | 10 | 15 | +1.25 [+1.07, +1.42] | +0.057 [+0.040, +0.073] | 15/15 | shearlet higher on PSNR and SSIM |
| gaussian | 20 | 15 | +1.45 [+1.08, +1.82] | +0.072 [+0.045, +0.099] | 15/15 | shearlet higher on PSNR and SSIM |
| gaussian | 30 | 15 | +1.35 [+0.84, +1.86] | +0.063 [+0.029, +0.097] | 14/15 | shearlet higher on PSNR and SSIM |

## 3. How do results change as noise intensity increases?

- **gaussian** (tuned): from level 10 to 30, mean PSNR gain over the noisy input goes 4.96 → 8.93 dB (wavelet) and 6.25 → 10.38 dB (shearlet); the shearlet−wavelet PSNR gap goes +1.29 → +1.45 dB.
- **salt_pepper** (tuned): from level 0.02 to 0.1, mean PSNR gain over the noisy input goes 0.59 → 9.61 dB (wavelet) and 2.92 → 10.77 dB (shearlet); the shearlet−wavelet PSNR gap goes +2.33 → +1.16 dB.
- **speckle** (tuned): from level 0.1 to 0.3, mean PSNR gain over the noisy input goes 5.31 → 9.20 dB (wavelet) and 6.43 → 10.31 dB (shearlet); the shearlet−wavelet PSNR gap goes +1.12 → +1.12 dB.
- **mixed** (tuned): from level 10 to 30, mean PSNR gain over the noisy input goes 4.34 → 9.41 dB (wavelet) and 8.46 → 10.79 dB (shearlet); the shearlet−wavelet PSNR gap goes +4.12 → +1.38 dB.

## 4. How well are image structures preserved? (SSIM)

SSIM is a proxy for structural similarity, not a direct measure of edge preservation. Pooled over levels (tuned parameters):

| noise | n | SSIM diff [95% CI] | runs where PSNR and SSIM disagree | verdict |
|---|---|---|---|---|
| gaussian | 45 | +0.064 [+0.051, +0.076] | 0 | shearlet higher on PSNR and SSIM |
| salt_pepper | 45 | +0.132 [+0.089, +0.175] | 0 | shearlet higher on PSNR and SSIM |
| speckle | 45 | +0.041 [+0.031, +0.051] | 0 | shearlet higher on PSNR and SSIM |
| mixed | 45 | +0.104 [+0.081, +0.126] | 0 | shearlet higher on PSNR and SSIM |

## 5. What is the runtime trade-off?

| method | runs | median_ms | mean_ms | std_ms | min_ms | max_ms | median_vs_wavelet |
|---|---|---|---|---|---|---|---|
| shearlet | 360 | 278.27 | 282.54 | 27.02 | 245.34 | 427.45 | 97.85 |
| wavelet | 360 | 2.84 | 3.01 | 0.60 | 2.16 | 5.97 | 1.00 |

Wavelet was faster in 100% of paired runs. Timings come from one machine; shearlet's one-off system setup (about 1–2 s per image size) is excluded from `processing_time` and would add to a first run.

## 6. Does performance change for different image types?

Mean over levels and seeds (tuned parameters):

| noise | image | n | PSNR diff dB [95% CI] | SSIM diff [95% CI] | verdict |
|---|---|---|---|---|---|
| gaussian | camera | 15 | +1.95 [+1.80, +2.10] | +0.088 [+0.073, +0.103] | shearlet higher on PSNR and SSIM |
| salt_pepper | camera | 15 | +3.35 [+2.27, +4.42] | +0.122 [+0.070, +0.173] | shearlet higher on PSNR and SSIM |
| speckle | camera | 15 | +1.83 [+1.73, +1.93] | +0.071 [+0.055, +0.086] | shearlet higher on PSNR and SSIM |
| mixed | camera | 15 | +2.84 [+2.35, +3.33] | +0.111 [+0.092, +0.131] | shearlet higher on PSNR and SSIM |
| gaussian | moon | 15 | +0.60 [+0.49, +0.72] | +0.012 [+0.009, +0.015] | shearlet higher on PSNR and SSIM |
| salt_pepper | moon | 15 | +3.66 [+1.49, +5.82] | +0.166 [+0.045, +0.288] | shearlet higher on PSNR and SSIM |
| speckle | moon | 15 | +0.48 [+0.39, +0.58] | +0.008 [+0.006, +0.010] | shearlet higher on PSNR and SSIM |
| mixed | moon | 15 | +2.20 [+0.88, +3.51] | +0.099 [+0.028, +0.169] | shearlet higher on PSNR and SSIM |
| gaussian | coins | 15 | +1.64 [+1.54, +1.73] | +0.091 [+0.080, +0.103] | shearlet higher on PSNR and SSIM |
| salt_pepper | coins | 15 | +2.86 [+2.17, +3.56] | +0.108 [+0.070, +0.146] | shearlet higher on PSNR and SSIM |
| speckle | coins | 15 | +1.26 [+1.15, +1.38] | +0.045 [+0.034, +0.055] | shearlet higher on PSNR and SSIM |
| mixed | coins | 15 | +2.08 [+1.75, +2.41] | +0.102 [+0.095, +0.108] | shearlet higher on PSNR and SSIM |

## 7. Are there cases where one method is preferable for a specific criterion?

- **shearlet higher on PSNR and SSIM** (tuned): gaussian 10, gaussian 20, gaussian 30, salt_pepper 0.02, salt_pepper 0.05, salt_pepper 0.1, speckle 0.1, speckle 0.2, speckle 0.3, mixed 10, mixed 20, mixed 30
- **runtime**: wavelet faster in 100% of paired runs.

## 8. Failure cases and artifacts

| tuning | noise_type | kind | runs |
|---|---|---|---|
| default | gaussian | PSNR and SSIM favour different methods | 4 |
| default | salt_pepper | PSNR and SSIM favour different methods | 6 |
| default | salt_pepper | shearlet below noisy input on SSIM | 5 |
| default | speckle | PSNR and SSIM favour different methods | 4 |
| tuned | salt_pepper | shearlet below noisy input on SSIM | 1 |
| tuned | salt_pepper | wavelet below noisy input on SSIM | 10 |

Full list: `tables/failure_cases.csv`.

Notable cases to inspect by eye (`figures/gallery.png`):

- Largest shearlet PSNR advantage: moon_salt_pepper_0p05_seed46 (tuned); PSNR gain over noisy input: wavelet +2.90 dB, shearlet +12.15 dB; shearlet minus wavelet: +9.25 dB PSNR, +0.479 SSIM
- Largest wavelet PSNR advantage (or smallest shearlet advantage): moon_speckle_0p3_seed45 (tuned); PSNR gain over noisy input: wavelet +14.42 dB, shearlet +14.66 dB; shearlet minus wavelet: +0.23 dB PSNR, +0.002 SSIM
- Lowest PSNR gain over the noisy input (either method): moon_salt_pepper_0p02_seed45 (tuned); PSNR gain over noisy input: wavelet +0.37 dB, shearlet +1.87 dB; shearlet minus wavelet: +1.50 dB PSNR, +0.019 SSIM

Artifacts (ringing, streaks, blur, blockiness) cannot be read from the metrics. Look at the gallery and describe what you see in your own words.

## 9. Limitations

- Only 3 test image(s) (camera, coins, moon) and 5 seed(s): results describe these images, not images in general.
- 'Tuned' uses the clean image to choose each method's setting (oracle tuning). It shows each method's best case within an equal-size grid, not what a user without the clean image could obtain.
- For salt-and-pepper and speckle noise the noise level given to both methods is a blind estimate (MAD), because those noise levels are not standard deviations. Both transforms assume roughly Gaussian-like noise.
- Runtime was measured on one machine with Python/NumPy and is excluded from setup cost; relative timings may differ elsewhere.
- PSNR and SSIM are global scores. They do not capture local artifacts or perceptual quality, and they can disagree.
- Only one wavelet family (db4, level 3) and one shearlet configuration (3 scales) were tested.
- In 105 tuned runs the best setting was at the edge of the tuning grid (see runner warning), so tuned scores for those cases may understate what the method could reach.
